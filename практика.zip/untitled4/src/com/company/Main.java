package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Main extends JComponent implements KeyListener, ActionListener {
    Image wall = new ImageIcon ("src/wall.jpg").getImage();
    Image worm = new ImageIcon ("scr/worm.png").getImage();
    private int Rx = 0, Ry = 0, W = 50, H = 50;
    Timer t = new Timer (7, this);
    Rectangle rectangle = new Rectangle(Rx, Ry, W, H);


public void paint(Graphics g) {
    Graphics2D grph = (Graphics2D)g;
    grph.drawImage(wall, 0, 0, null);
    grph.drawImage(worm, 0, 0, 30,30, null);
    grph.fill(rectangle);
    t.start();

}


    public static void main(String[] args) {
    Main t = new Main();
    JFrame f = new JFrame( "test");
    f.setSize(520,520);
    f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    f.addKeyListener(t);
    f.add(new Main ());
    f.add(t);
    f.setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
    repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
if (e.getKeyCode()==KeyEvent.VK_RIGHT) {
    rectangle.setLocation(rectangle.x+15, rectangle.y);
    Rx+=1;
}
if (e.getKeyCode()==KeyEvent.VK_DOWN) {
    rectangle.setLocation(rectangle.x, rectangle.y+15);
    Ry+=1;
}
if (e.getKeyCode()==KeyEvent.VK_LEFT) {
    rectangle.setLocation(rectangle.x-15, rectangle.y);
    Ry+=1;
}
if (e.getKeyCode()==KeyEvent.VK_UP) {
    rectangle.setLocation(rectangle.x, rectangle.y-15);
    Ry+=1;
}
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
